﻿using System;

namespace DM
{
    public class Rand
    {
        static public Random random = new Random(); // Объект для случайных чисел
    }
}