﻿using System;

namespace DM
{
    class Nature
    {
        private int n;
        public int N
        {
            get
            {
                return n;
            }
        }

        public Nature (int n)
        {
            this.n = n;
        }

        public int NumDigits()
        {
            return n.ToString().Length;
        }

        public override string ToString()
        {
            return $"{n}";
        }
    }
}