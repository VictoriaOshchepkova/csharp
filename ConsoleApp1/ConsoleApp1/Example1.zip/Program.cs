﻿using System;
namespace DM
{
    class Program
    {
        static void Main()
        {
            int n = InputDataWithCheck.InputIntegerWithValidation($"Введите натуральное число (от 1 до {int.MaxValue})", 1, int.MaxValue);
            Nature a = new Nature(n);
            Console.WriteLine($"Поле имеет значение {a}");
            Console.WriteLine($"Поле имеет значение {a.N} - доступ к данному с использованием свойства");
            Console.WriteLine($"В числе {a} содержится {a.NumDigits()} цифр(ы)");
            Nature b = new Nature(Rand.random.Next(1, 1000000));
            Console.WriteLine($"Случайное значение {b}");
            Console.WriteLine($"В числе {b} содержится {b.NumDigits()} цифр(ы)");
        }
    }
}